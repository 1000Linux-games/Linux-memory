#!/bin/bash

APP_NAME="Linux Memory"
INSTALL_DIR="$HOME/.local/share/linux-memory"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/128x128/apps"

zenity --info \
--title="$APP_NAME Installer" \
--text="Willkommen beim $APP_NAME Installer!\n\nDas Spiel wird jetzt installiert."

# Ordner anlegen
mkdir -p "$INSTALL_DIR" "$BIN_DIR" "$DESKTOP_DIR" "$ICON_DIR"

# Dateien kopieren
cp linux_memory_full.py "$INSTALL_DIR/"
cp -r images "$INSTALL_DIR/"
cp -r audio "$INSTALL_DIR/"
cp linux-memory.png "$INSTALL_DIR/"

# Startskript
cat << EOF > "$BIN_DIR/linux-memory"
#!/bin/bash
cd "$INSTALL_DIR"
python3 linux_memory_full.py
EOF

chmod +x "$BIN_DIR/linux-memory"

# Desktop-Datei
cat << EOF > "$DESKTOP_DIR/linux-memory.desktop"
[Desktop Entry]
Type=Application
Name=Linux Memory
Comment=Linux Memory Spiel mit Linux-Maskottchen
Exec=linux-memory
Icon=linux-memory
Terminal=false
Categories=Game;Puzzle;
EOF

# Icon
cp "$INSTALL_DIR/linux-memory.png" "$ICON_DIR/"

# Desktop-Datenbank aktualisieren
update-desktop-database "$DESKTOP_DIR" >/dev/null 2>&1

zenity --info \
--title="$APP_NAME Installer" \
--text="$APP_NAME wurde erfolgreich installiert!\n\nDu findest es jetzt im Startmenü unter »Spiele«."

exit 0

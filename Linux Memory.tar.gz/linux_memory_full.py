# (Code omitted here for brevity; same as previously generated correct version)
import pygame
import sys
import random
import configparser
from pathlib import Path

# ==================================================
# BASIS-PFADE
# ==================================================
BASE = Path(__file__).resolve().parent
IMG_DIR = BASE / "images"
AUD_DIR = BASE / "audio"
CONFIG_FILE = BASE / "config.ini"

# ==================================================
# CONFIG.INI
# ==================================================
config = configparser.ConfigParser()

if not CONFIG_FILE.exists():
    config["DISPLAY"] = {
        "width": "1280",
        "height": "800",
        "fullscreen": "false"
    }
    config["AUDIO"] = {
        "music": "true",
        "volume": "0.5"
    }
    with open(CONFIG_FILE, "w") as f:
        config.write(f)

config.read(CONFIG_FILE)

WIDTH = int(config["DISPLAY"]["width"])
HEIGHT = int(config["DISPLAY"]["height"])
FULLSCREEN = config["DISPLAY"].getboolean("fullscreen")

MUSIC_ON = config["AUDIO"].getboolean("music")
MUSIC_VOLUME = float(config["AUDIO"]["volume"])

# ==================================================
# PYGAME INIT
# ==================================================
pygame.init()
flags = pygame.FULLSCREEN if FULLSCREEN else 0
screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)
pygame.display.set_caption("Linux Memory")
clock = pygame.time.Clock()
FONT = pygame.font.SysFont("arial", 28)

# ==================================================
# MUSIK (nur Hintergrund)
# ==================================================
if MUSIC_ON:
    try:
        pygame.mixer.init()
        pygame.mixer.music.load(str(AUD_DIR / "music.mp3"))
        pygame.mixer.music.set_volume(MUSIC_VOLUME)
        pygame.mixer.music.play(-1)
    except Exception as e:
        print("Musik konnte nicht geladen werden:", e)

# ==================================================
# KARTEN / BILDER
# ==================================================
IMAGE_FILES = [
    "tux.png",
    "kde_dragon.png",
    "xfce_mouse.png",
    "ubuntu.png",
    "arch.png",
    "opensuse.png"
]

cards = []
for name in IMAGE_FILES:
    img = pygame.image.load(str(IMG_DIR / name)).convert_alpha()
    cards.append((img, name))
    cards.append((img, name))

random.shuffle(cards)

# ==================================================
# SPIELFELD
# ==================================================
COLS, ROWS = 4, 3
CARD_SIZE = int(min(WIDTH // (COLS + 1), HEIGHT // (ROWS + 2)) * 0.8)

scaled_cards = []
for img, name in cards:
    scaled = pygame.transform.smoothscale(img, (CARD_SIZE, CARD_SIZE))
    scaled_cards.append((scaled, name))
cards = scaled_cards

offset_x = (WIDTH - COLS * CARD_SIZE) // 2
offset_y = (HEIGHT - ROWS * CARD_SIZE) // 2

revealed = [False] * len(cards)
matched = [False] * len(cards)

first_card = None
lock = False

# ==================================================
# ZEICHNEN
# ==================================================
def draw_board():
    screen.fill((30, 30, 30))
    for i, (img, _) in enumerate(cards):
        x = offset_x + (i % COLS) * CARD_SIZE
        y = offset_y + (i // COLS) * CARD_SIZE
        rect = pygame.Rect(x, y, CARD_SIZE, CARD_SIZE)

        if revealed[i] or matched[i]:
            screen.blit(img, rect)
        else:
            pygame.draw.rect(screen, (90, 90, 90), rect)
            pygame.draw.rect(screen, (140, 140, 140), rect, 2)

    pygame.display.flip()

# ==================================================
# SPIEL-LOOP
# ==================================================
def game_loop():
    global first_card, lock

    while True:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return

            if event.type == pygame.MOUSEBUTTONDOWN and not lock:
                mx, my = pygame.mouse.get_pos()

                for i in range(len(cards)):
                    x = offset_x + (i % COLS) * CARD_SIZE
                    y = offset_y + (i // COLS) * CARD_SIZE
                    rect = pygame.Rect(x, y, CARD_SIZE, CARD_SIZE)

                    if rect.collidepoint(mx, my):
                        if not revealed[i] and not matched[i]:
                            revealed[i] = True

                            if first_card is None:
                                first_card = i
                            else:
                                lock = True
                                pygame.display.flip()
                                pygame.time.delay(700)

                                # >>> KORREKTER PAAR-VERGLEICH <<<
                                if cards[first_card][1] == cards[i][1]:
                                    matched[first_card] = True
                                    matched[i] = True
                                else:
                                    revealed[first_card] = False
                                    revealed[i] = False

                                first_card = None
                                lock = False

        draw_board()

        if all(matched):
            win = FONT.render("Gewonnen! ESC zum Beenden", True, (0, 220, 0))
            screen.blit(win, (WIDTH // 2 - win.get_width() // 2, 20))
            pygame.display.flip()

# ==================================================
# STARTMENÜ
# ==================================================
def start_menu():
    while True:
        screen.fill((20, 20, 20))
        title = FONT.render("Linux Memory", True, (255, 255, 255))
        info = FONT.render("ENTER = Start | ESC = Beenden", True, (180, 180, 180))

        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 40))
        screen.blit(info, (WIDTH // 2 - info.get_width() // 2, HEIGHT // 2 + 10))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

# ==================================================
# MAIN
# ==================================================
def main():
    while True:
        start_menu()
        game_loop()

if __name__ == "__main__":
    main()
